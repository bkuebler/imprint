/* version 3.0.1 $Id: 3.0.1.sql 13 2011-08-14 12:48:03Z mgebhardt $ */

ALTER TABLE `#__impressum` ADD `templateemail` varchar(255) NOT NULL default '';
ALTER TABLE `#__impressum` CHANGE `aktiv` `default` tinyint NOT NULL default 0;