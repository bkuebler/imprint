<?php
/**
 * @version		3.1 $Id: remark.php 77 2012-09-23 16:57:33Z chris-schmidt $
 * @package		Joomla
 * @subpackage	Imprint
 * @copyright	(C) 2011 - 2012 Imprint Team
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die( 'Restricted access' );

jimport( 'joomla.application.component.controllerform' );

/**
 * Remark controller class.
 * 
 * @package		Joomla
 * @subpackage	Imprint
 * @since		3.1
 */
class ImprintControllerRemark extends JControllerForm
{
	
}