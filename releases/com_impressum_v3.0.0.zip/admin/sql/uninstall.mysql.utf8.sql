/* version 3.0 $Id$ */
 
DROP TABLE `#__impressum`;