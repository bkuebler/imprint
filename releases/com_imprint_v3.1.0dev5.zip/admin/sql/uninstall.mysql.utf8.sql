/* version 3.1.0 $Id$ */
 
DROP TABLE `#__imprint_imprints`;