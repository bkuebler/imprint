/**
 * @version		3.1 $Id: remark.js 77 2012-09-23 16:57:33Z chris-schmidt $
 * @package		Joomla
 * @subpackage	Imprint
 * @copyright	(C) 2011 - 2012 Imprint Team
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

/**
 * Method to validate the name text box.
 *  
 * @author	mgebhardt
 * @since	3.1
 */
window.addEvent('domready', function() {
	document.formvalidator.setHandler('name',
		function (value) {
			regex=/^[^0-9]+$/;
			return regex.test(value);
	});
});