<?php
/**
 * @version		3.0.1 $Id: default_head.php 77 2012-09-23 16:57:33Z chris-schmidt $
 * @package		Joomla
 * @subpackage	Imprint
 * @copyright	(C) 2011 - 2012 Imprint Team
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<tr>
        <th width="1%">
                <input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->items); ?>);" />
        </th>                     
        <th width="5%">
                <?php echo JHtml::_('grid.sort',  'COM_IMPRINT_IMPRINTS_DEFAULT', 'default', $this->listDirn, $this->listOrder); ?>
        </th>
        <th>
                <?php echo JHtml::_('grid.sort',  'COM_IMPRINT_IMPRINTS_NAME', 'name', $this->listDirn, $this->listOrder); ?>
        </th>
</tr>

