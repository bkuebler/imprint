<?php
/**
 * @version		3.0.1 $Id: default_foot.php 77 2012-09-23 16:57:33Z chris-schmidt $
 * @package		Joomla
 * @subpackage	Imprint
 * @copyright	(C) 2011 - 2012 Imprint Team
 * @license		GNU General Public License version 2 or later; see LICENSE.txt
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>
<tr>
        <td colspan="3"><?php echo $this->pagination->getListFooter(); ?></td>
</tr>