/* version 3.1.0 $Id: uninstall.mysql.utf8.sql 62 2012-02-17 16:06:39Z mgebhardt $ */
 
DROP TABLE IF EXISTS `#__imprints_relation`;
DROP TABLE IF EXISTS `#__imprints_imprints`;
DROP TABLE IF EXISTS `#__imprints_remarks`;