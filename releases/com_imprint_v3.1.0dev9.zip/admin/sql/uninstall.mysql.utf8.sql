/* version 3.1.0 $Id: uninstall.mysql.utf8.sql 44 2012-02-16 21:47:50Z mgebhardt $ */
 
DROP TABLE `#__imprint_imprints`;