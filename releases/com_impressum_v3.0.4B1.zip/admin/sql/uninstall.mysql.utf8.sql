/* version 3.0 $Id: uninstall.mysql.utf8.sql 1 2011-07-26 12:05:06Z mgebhardt $ */
 
DROP TABLE `#__impressum`;