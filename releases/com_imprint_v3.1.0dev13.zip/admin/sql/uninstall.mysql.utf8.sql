/* version 3.1.0 $Id: uninstall.mysql.utf8.sql 76 2012-05-20 09:20:21Z mgebhardt $ */

DROP TABLE IF EXISTS `#__imprints_imprints`;
DROP TABLE IF EXISTS `#__imprints_remarks`;